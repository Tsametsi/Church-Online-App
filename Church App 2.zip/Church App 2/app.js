const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const nodemailer = require('nodemailer');
const schedule = require('node-schedule');
const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static(__dirname)); // Serve static files

// Create a connection to the database
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',  // replace with your MySQL username
    password: 'Gwacela30#',  // replace with your MySQL password
    database: 'church_app_database'
});

// Connect to the database
db.connect((err) => {
    if (err) {
        console.error('Error connecting to the database:', err);
        return;
    }
    console.log('Connected to the database');
});

// Handle login POST request
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    // Check if the user exists in the database
    const query = 'SELECT * FROM logged_in_users WHERE username = ? AND password = ?';
    db.query(query, [username, password], (err, results) => {
        if (err) {
            console.error('Error querying the database:', err);
            res.status(500).send('Internal server error');
            return;
        }

        if (results.length > 0) {
            // Authentication successful, redirect to Home.html
            res.redirect('/Home.html');
        } else {
            // Authentication failed
            res.send('Invalid username or password');
        }
    });
});

// Handle signup POST request
app.post('/signup', (req, res) => {
    const { username, email, password } = req.body;

    // Check if the username or email already exists in the database
    const checkQuery = 'SELECT * FROM logged_in_users WHERE username = ? OR email = ?';
    db.query(checkQuery, [username, email], (err, results) => {
        if (err) {
            console.error('Error checking database:', err);
            res.status(500).send('Internal server error');
            return;
        }

        if (results.length > 0) {
            // User already exists
            res.redirect('/Signup.html?message=User%20already%20exists');
        } else {
            // Insert new user into the database
            const insertQuery = 'INSERT INTO logged_in_users (username, email, password) VALUES (?, ?, ?)';
            db.query(insertQuery, [username, email, password], (err, results) => {
                if (err) {
                    console.error('Error inserting into database:', err);
                    res.status(500).send('Internal server error');
                    return;
                }

                // Send confirmation email to the user
                const transporter = nodemailer.createTransport({
                    service: 'gmail',
                    auth: {
                        user: 'followme303030@gmail.com',  // sender's email
                        pass: 'Meyerton28#'    // sender's email password
                    }
                });

                const mailOptions = {
                    from: 'followme303030@gmail.com',  // sender's email
                    to: email,  // receiver's email
                    subject: 'Welcome to Our Church App',
                    text: `Dear ${username},\n\nWelcome to our church app! Your account has been successfully created.`
                };

                transporter.sendMail(mailOptions, (error, info) => {
                    if (error) {
                        console.error('Error sending email:', error);
                        res.status(500).send('Internal server error');
                    } else {
                        console.log('Email sent: ' + info.response);
                        // Redirect to login page after signup
                        res.redirect('/Login.html?message=Sign%20up%20successful.%20Please%20login.');
                    }
                });
            });
        }
    });
});

// Handle Church Events GET request
app.get('/church-events', (req, res) => {
    // Fetch events from the database
    const query = 'SELECT * FROM events';
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching events:', err);
            res.status(500).send('Internal server error');
            return;
        }

        // Render Events.html with fetched events data
        res.render('Events.html', { events: results });
    });
});

// Schedule event notifications
scheduleEventsNotifications();

function scheduleEventsNotifications() {
    // Fetch all upcoming events
    const query = 'SELECT * FROM events WHERE date_time > NOW() ORDER BY date_time ASC';
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching upcoming events:', err);
            return;
        }

        // Schedule notifications for each event
        results.forEach(event => {
            scheduleNotification(event);
        });
    });
}

function scheduleNotification(event) {
    const notificationDate = new Date(event.date_time);
    // Set notification time 24 hours before the event
    notificationDate.setHours(notificationDate.getHours() - 24);

    // Schedule notification job
    schedule.scheduleJob(notificationDate, () => {
        sendEventNotification(event);
    });
}

function sendEventNotification(event) {
    // Implement notification logic (e.g., send email notification)
    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: 'followme303030@gmail.com',  // sender's email
            pass: 'Meyerton28#'    // sender's email password
        }
    });

    const mailOptions = {
        from: 'followme303030@gmail.com',
        to: 'recipient@example.com',  // replace with recipient's email
        subject: `Upcoming Event: ${event.title}`,
        text: `Dear church member,\n\nJust a reminder that "${event.title}" is happening on ${event.date_time}.`
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.error('Error sending event notification:', error);
        } else {
            console.log('Event notification sent:', info.response);
        }
    });
}

// Start server
app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});

